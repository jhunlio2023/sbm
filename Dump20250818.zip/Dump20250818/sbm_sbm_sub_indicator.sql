-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sbm
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sbm_sub_indicator`
--

DROP TABLE IF EXISTS `sbm_sub_indicator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sbm_sub_indicator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `priciple_id` int DEFAULT NULL,
  `i_no` int DEFAULT NULL,
  `i_status` int DEFAULT '0',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sbm_sub_indicator`
--

LOCK TABLES `sbm_sub_indicator` WRITE;
/*!40000 ALTER TABLE `sbm_sub_indicator` DISABLE KEYS */;
INSERT INTO `sbm_sub_indicator` VALUES (1,1,1,0,'Grade 3 learners achieve the proficiency level for each cluster of early language, literacy, and numeracy skills'),(2,1,2,NULL,'Grade 6,10, and 12  learners achieve the proficiency level in all 21st century skills and core learning areas in the National Achievement Test (NAT)'),(3,1,3,NULL,'School-Base ALS learners attain certification as elementary and junior high school completers'),(4,1,4,NULL,'Teachers prepare contextualized learning materials responsive to the needs of learners'),(5,1,5,NULL,'Teachers conduct remediation activities to address learning gaps in reading, and comprehension, science and technology, and mathematics'),(6,1,6,NULL,'Teachers integrate topics promoting peace and DepEd core values'),(7,1,7,NULL,'The school conducts test item analysis to inform its teaching and learning process'),(8,1,8,NULL,'The school engages local industries to strengthen its TLE-TVL course offerings'),(9,2,9,NULL,'The school has zero child bullying incidence'),(10,2,10,NULL,'The school has zero child abuse incidence'),(11,2,11,NULL,'The school has reduced its drop-out incidence'),(12,2,12,NULL,'The school conducts culture-sensitive activities'),(13,2,13,NULL,'The school provides access to learning experiences for the disadvantage, OSYs, and adult learners'),(14,2,14,NULL,'The school has a functional shcool-base ALS program'),(15,2,15,NULL,'The school has a fuctional child-protection committee'),(16,2,16,NULL,'The school has a fuctional DRRM plan'),(17,2,17,NULL,'The school has a functional support mechanism for mental wellness'),(18,2,18,NULL,'The school has special education - and PWD-friendly facilities'),(19,3,19,NULL,'The school develops a strategic plan'),(20,3,20,NULL,'The school has a functional school-community planning team'),(21,3,21,NULL,'The school has a functional Supreme Student Government/Supreme Pupil Government'),(22,3,22,NULL,'The school innovates in its provision of frontline services to stakeholders'),(23,4,23,NULL,'The school\'s strategic plan is operationalized through an implementation plan'),(24,4,24,NULL,'The school has a functional School Governance Council (SGC)'),(25,4,25,NULL,'The school has a functional Parent-Teacher Association (PTA)'),(26,4,26,NULL,'The school collaborates with stakeholders and other schools in strengthening partnerships'),(27,4,27,NULL,'The school monitors and evaluates its programs, projects, and activities'),(28,4,28,NULL,'The school maintains an average rating of satisfactory form its internal and external stakeholders'),(29,5,29,NULL,'School personnel achieve an average rating of very satisfactory in the individual performance commitment and review'),(30,5,30,NULL,'The school achieves an average rating of very satisfactory in the office performance commitment and review'),(31,5,31,NULL,'The school conducts needs-based Learning Action Cells and Learning & Development activities'),(32,5,32,NULL,'The school facilitates the promotion and continuous professional development of its personnel'),(33,5,33,NULL,'The school recognizes and rewards milestone achievements of its personnel'),(34,5,34,NULL,'The school facilitates receipt of correct salaries, allowances, and other additional compensation in a timely manner'),(35,5,35,NULL,'Teacher workload is distributed fairly and equitably'),(36,6,36,NULL,'The school inspects its infrastructure and facilities'),(37,6,37,NULL,'The school initiates improvement of its infrastructure and facilities'),(38,6,38,NULL,'The school has a functional library'),(39,6,39,NULL,'The school has functional water, electric, and internet facilities'),(40,6,40,NULL,'The school has a functional computer laboratory/classroom'),(41,6,41,NULL,'The school achieves a 72-100% utilization rate of its Maintenance and Other Operating Expenses (MOOE)'),(42,6,42,NULL,'The school liquidates 100% of its utilized MOOE');
/*!40000 ALTER TABLE `sbm_sub_indicator` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  9:56:26
