-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sbm
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL DEFAULT '',
  `password` varchar(150) NOT NULL DEFAULT '',
  `position` varchar(45) NOT NULL DEFAULT '',
  `fname` varchar(45) NOT NULL DEFAULT '',
  `mname` varchar(45) NOT NULL DEFAULT '',
  `lname` varchar(45) NOT NULL DEFAULT '',
  `gender` tinyint unsigned NOT NULL DEFAULT '0',
  `image` varchar(500) NOT NULL DEFAULT '',
  `stat` int unsigned NOT NULL DEFAULT '0',
  `sec` int unsigned NOT NULL DEFAULT '0',
  `r_id` int DEFAULT NULL,
  `p_id` int DEFAULT NULL,
  `d_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'sa','$2y$10$rshOCBDTBvXpi6oeJyx2DOxNetEFMXBaUacrkcBWtn17VbSVn7iiy','admin','RENREN','OJENDRAS','BUGHAO',0,'renren.jpg',0,2,12,NULL,NULL),(31,'ic','$2y$10$rXC1RWa8iS/Df/5qHnoK4.ValpJCfEW.qqoFDb3r.8WIOBCWO8UVi','district','IVYCLAIRE','BUGHAO','CRODUA',0,'',0,0,12,61,9),(32,'division','$2y$10$Tev0G/ooNs7jPjtxDXDy3ew3kBA2TQ/wkfzGem9L.Sr5vmcxFbsFy','division','DONNA','LOPIGA','BALO',0,'',0,0,12,61,0),(33,'134717','$2y$10$YC8wVFd3qm5EBqwTEo4lS.R1bUaR25EW.ks9XsFHENKP61PjQB01e','school','AUREO','D. ','CAÑAL ES',0,'',0,0,12,61,1),(35,'division2','$2y$10$jiqMg7w/oFrxUFCcH1IPMOPqC1DP4M4VtLJcQBWYQdzEzlFkJGqaG','division','DONNA','OJENDRAS','CAÑAL ES',0,'',0,0,12,61,2),(36,'district','$2y$10$tTfJjLEVC4/pP.pKRnDpw.cxDRZMkiheYvDF3tbZR2mjLF914lT/C','district','DISTRICT','','USER',0,'',0,0,12,61,1),(37,'region','$2y$10$zCCVXNot6s2ThRJhqVyjSeKevXtFuDibBNbbhbs3O/Q9NQkJYig3.','region','REGION','','USER',0,'',0,0,12,0,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  9:56:25
