-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sbm
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sbm_ta`
--

DROP TABLE IF EXISTS `sbm_ta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sbm_ta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fy` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `school_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `q1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q7` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q8` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q9` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q10` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q11` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q12` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q13` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q14` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q15` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q16` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q17` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q18` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q19` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q20` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q21` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q22` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q23` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q24` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q25` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q26` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q27` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q28` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q29` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q30` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q31` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q32` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q33` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q34` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q35` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q36` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q37` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q38` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q39` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q40` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q41` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q42` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq7` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq8` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq9` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq10` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq11` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq12` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq13` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq14` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq15` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq16` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq17` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq18` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq19` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq20` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq21` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq22` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq23` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq24` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq25` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq26` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq27` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq28` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq29` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq30` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq31` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq32` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq33` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq34` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq35` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq36` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq37` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq38` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq39` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq40` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq41` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `qq42` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `a1` tinyint(1) DEFAULT NULL,
  `a2` tinyint(1) DEFAULT NULL,
  `a3` tinyint(1) DEFAULT NULL,
  `a4` tinyint(1) DEFAULT NULL,
  `a5` tinyint(1) DEFAULT NULL,
  `a6` tinyint(1) DEFAULT NULL,
  `a7` tinyint(1) DEFAULT NULL,
  `a8` tinyint(1) DEFAULT NULL,
  `a9` tinyint(1) DEFAULT NULL,
  `a10` tinyint(1) DEFAULT NULL,
  `a11` tinyint(1) DEFAULT NULL,
  `a12` tinyint(1) DEFAULT NULL,
  `a13` tinyint(1) DEFAULT NULL,
  `a14` tinyint(1) DEFAULT NULL,
  `a15` tinyint(1) DEFAULT NULL,
  `a16` tinyint(1) DEFAULT NULL,
  `a17` tinyint(1) DEFAULT NULL,
  `a18` tinyint(1) DEFAULT NULL,
  `a19` tinyint(1) DEFAULT NULL,
  `a20` tinyint(1) DEFAULT NULL,
  `a21` tinyint(1) DEFAULT NULL,
  `a22` tinyint(1) DEFAULT NULL,
  `a23` tinyint(1) DEFAULT NULL,
  `a24` tinyint(1) DEFAULT NULL,
  `a25` tinyint(1) DEFAULT NULL,
  `a26` tinyint(1) DEFAULT NULL,
  `a27` tinyint(1) DEFAULT NULL,
  `a28` tinyint(1) DEFAULT NULL,
  `a29` tinyint(1) DEFAULT NULL,
  `a30` tinyint(1) DEFAULT NULL,
  `a31` tinyint(1) DEFAULT NULL,
  `a32` tinyint(1) DEFAULT NULL,
  `a33` tinyint(1) DEFAULT NULL,
  `a34` tinyint(1) DEFAULT NULL,
  `a35` tinyint(1) DEFAULT NULL,
  `a36` tinyint(1) DEFAULT NULL,
  `a37` tinyint(1) DEFAULT NULL,
  `a38` tinyint(1) DEFAULT NULL,
  `a39` tinyint(1) DEFAULT NULL,
  `a40` tinyint(1) DEFAULT NULL,
  `a41` tinyint(1) DEFAULT NULL,
  `a42` tinyint(1) DEFAULT NULL,
  `f1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f7` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f8` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f9` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f10` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f11` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f12` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f13` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f14` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f15` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f16` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f17` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f18` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f19` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f20` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f21` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f22` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f23` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f24` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f25` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f26` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f27` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f29` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f30` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f31` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f32` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f33` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f34` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f35` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f36` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f37` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f38` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f39` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f40` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f41` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f42` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `f28` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `stat` int DEFAULT NULL,
  `district` int NOT NULL,
  `region` int DEFAULT NULL,
  `division` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sbm_ta`
--

LOCK TABLES `sbm_ta` WRITE;
/*!40000 ALTER TABLE `sbm_ta` DISABLE KEYS */;
INSERT INTO `sbm_ta` VALUES (197,'2025','134717','fdsa','fdsafdsa','regr','gfdsgds','gfds','fdsaf','dsafsa','fdsa','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','fdsaf','fdsa','sdgfds','gfds','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',2,3,2,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'fdasfsafd','dfsafsa','fdsafd','gfdsg','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',0,1,12,61);
/*!40000 ALTER TABLE `sbm_ta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  9:56:26
