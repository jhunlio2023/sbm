-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sbm
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `province`
--

DROP TABLE IF EXISTS `province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `province` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `region_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `province`
--

LOCK TABLES `province` WRITE;
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
INSERT INTO `province` VALUES (1,'Ilocos Norte',1),(2,'Ilocos Sur',1),(3,'La Union',1),(4,'Pangasinan',1),(5,'Batanes',2),(6,'Cagayan',2),(7,'Isabela',2),(8,'Nueva Vizcaya',2),(9,'Quirino',2),(10,'Aurora',3),(11,'Bataan',3),(12,'Bulacan',3),(13,'Nueva Ecija',3),(14,'Pampanga',3),(15,'Tarlac',3),(16,'Zambales',3),(17,'Batangas',4),(18,'Cavite',4),(19,'Laguna',4),(20,'Quezon',4),(21,'Rizal',4),(22,'Marinduque',5),(23,'Occidental Mindoro',5),(24,'Oriental Mindoro',5),(25,'Palawan',5),(26,'Romblon',5),(27,'Albay',6),(28,'Camarines Norte',6),(29,'Camarines Sur',6),(30,'Catanduanes',6),(31,'Masbate',6),(32,'Sorsogon',6),(33,'Aklan',7),(34,'Antique',7),(35,'Capiz',7),(36,'Guimaras',7),(37,'Iloilo',7),(38,'Negros Occidental',7),(39,'Bohol',8),(40,'Cebu',8),(41,'Negros Oriental',8),(42,'Siquijor',8),(43,'Biliran',9),(44,'Eastern Samar',9),(45,'Leyte',9),(46,'Northern Samar',9),(47,'Samar (Western Samar)',9),(48,'Southern Leyte',9),(49,'Zamboanga del Norte',10),(50,'Zamboanga del Sur',10),(51,'Zamboanga Sibugay',10),(52,'Bukidnon',11),(53,'Camiguin',11),(54,'Lanao del Norte',11),(55,'Misamis Occidental',11),(56,'Misamis Oriental',11),(57,'Davao de Oro (Compostela Valley)',12),(58,'Davao del Norte',12),(59,'Davao del Sur',12),(60,'Davao Occidental',12),(61,'Davao Oriental',12),(62,'Cotabato (North Cotabato)',13),(63,'Sarangani',13),(64,'South Cotabato',13),(65,'Sultan Kudarat',13),(66,'Agusan del Norte',14),(67,'Agusan del Sur',14),(68,'Dinagat Islands',14),(69,'Surigao del Norte',14),(70,'Surigao del Sur',14),(71,'Manila',15),(72,'Quezon City',15),(73,'Caloocan',15),(74,'Makati',15),(75,'Mandaluyong',15),(76,'Marikina',15),(77,'Muntinlupa',15),(78,'Las Piñas',15),(79,'Parañaque',15),(80,'Pasay',15),(81,'Pasig',15),(82,'San Juan',15),(83,'Taguig',15),(84,'Valenzuela',15),(85,'Navotas',15),(86,'Malabon',15),(87,'Pateros (only municipality)',15),(88,'Abra',16),(89,'Apayao',16),(90,'Benguet',16),(91,'Ifugao',16),(92,'Kalinga',16),(93,'Mountain Province',16),(94,'Basilan',17),(95,'Lanao del Sur',17),(96,'Maguindanao del Norte',17),(97,'Maguindanao del Sur',17),(98,'Sulu',17),(99,'Tawi-Tawi',17),(100,'Negros Occidental',18),(101,'Negros Oriental',18),(102,'Siquijor (included in the 2024 version of NIR)',18),(103,'City of Mati',12);
/*!40000 ALTER TABLE `province` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  9:56:25
