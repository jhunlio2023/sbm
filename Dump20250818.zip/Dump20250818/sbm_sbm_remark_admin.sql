-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sbm
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sbm_remark_admin`
--

DROP TABLE IF EXISTS `sbm_remark_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sbm_remark_admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `q1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `q2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q7` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q8` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q9` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q10` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q11` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q12` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q13` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q14` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q15` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q16` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q17` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q18` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q19` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q20` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q21` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q22` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q23` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q24` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q25` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q26` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q27` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q28` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q29` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q30` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q31` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q32` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q33` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q34` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q35` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q36` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q37` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q38` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q39` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q40` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q41` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `q42` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `school_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fy` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs3` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs4` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs5` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs6` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs7` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs8` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs9` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs10` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs11` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs12` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs13` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs14` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs15` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs16` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs17` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs18` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs19` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs20` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs21` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs22` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs23` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs24` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs25` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs26` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs27` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs28` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs29` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs30` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs31` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs32` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs33` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs34` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs35` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs36` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs37` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs38` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs39` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs40` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs41` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fs42` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sbm_remark_admin`
--

LOCK TABLES `sbm_remark_admin` WRITE;
/*!40000 ALTER TABLE `sbm_remark_admin` DISABLE KEYS */;
INSERT INTO `sbm_remark_admin` VALUES (3,'fdasf','saf','fdsaffdasfd afdasfda','fdsa','fdsa','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','134717','2025','fdsafsa','asfd','fdsa','fdsa','fdsafsa','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');
/*!40000 ALTER TABLE `sbm_remark_admin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-18  9:56:25
